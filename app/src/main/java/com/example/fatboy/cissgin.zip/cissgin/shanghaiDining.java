package com.example.fatboy.cissgin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class shanghaiDining extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shanghai_dining);
        getSupportActionBar().hide();

    }
}
