package com.example.fatboy.cissgin;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Fatboy on 6/1/2018.
 */

public class ginschedule extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {

        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ginschedule);
    }
}